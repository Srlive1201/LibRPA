#!/usr/bin/env python3
import pathlib
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
import numpy as np

from mushroom.core.kpoints import KPathLinearizer
from mushroom.aims.stdout import StdOut
from mushroom.aims.input import read_control, get_path_ksymbols
from mushroom.aims.band import read_band_output
from mushroom.aims.analyse import get_chemical_potential, get_recp_latt_from_geometry
from mushroom.librpa import read_quasi_particle_energies_stdout


def apply_style(fontsize=16):
    plt.rcParams["font.family"] = ["serif",] + plt.rcParams["font.family"]
    plt.rcParams["font.serif"] = ["Times New Roman",] + plt.rcParams["font.serif"]
    plt.rcParams["font.sans-serif"] = ["Helvetica",] + plt.rcParams["font.sans-serif"]
    plt.rcParams["font.monospace"] = ["Courier",] + plt.rcParams["font.monospace"]
    # plt.rcParams['mathtext.fontset'] = 'dejavuserif'
    plt.rcParams['mathtext.fontset'] = 'cm'
    plt.rcParams["xtick.direction"] = "in"
    plt.rcParams["ytick.direction"] = "in"
    plt.rcParams["legend.frameon"] = True
    plt.rcParams["legend.fancybox"] = True
    # disable legend transparency
    plt.rcParams["legend.framealpha"] = 1.0
    plt.rcParams["savefig.dpi"] = 300
    plt.rcParams["savefig.transparent"] = False
    # plt.rcParams["image.cmap"] = cmap
    plt.rcParams["font.size"] = fontsize
    plt.rcParams["lines.markersize"] = 12
    plt.rcParams["xtick.major.size"] *= 1.5     # major tick size in points
    plt.rcParams["xtick.minor.size"] *= 1.5       # minor tick size in points
    plt.rcParams["xtick.major.width"] *= 1.5     # major tick width in points
    plt.rcParams["xtick.minor.width"] *= 1.5     # minor tick width in points
    plt.rcParams["ytick.major.size"] *= 1.5     # major tick size in points
    plt.rcParams["ytick.minor.size"] *= 1.5       # minor tick size in points
    plt.rcParams["ytick.major.width"] *= 1.5     # major tick width in points
    plt.rcParams["ytick.minor.width"] *= 1.5     # minor tick width in points
    # axis line width are also adjusted to make it consistent
    plt.rcParams["axes.linewidth"] *= 1.5


apply_style()
DATADIR = pathlib.Path(".")
MARKERSIZE = 60


def set_ax(ax, kp, ksymbols, emin, emax, with_label=True):
    ax.set_xlim(kp.x[0], kp.x[-1])
    ax.set_ylim(ymin=emin, ymax=emax)
    ax.axhline(0.0, ls=":", color="k")
    ax.xaxis.grid(color='k')
    ax.set_axisbelow(True)
    ax.xaxis.set_ticks(kp.special_x, labels=ksymbols)
    if with_label:
        ax.set_ylabel("Energy [eV]", fontsize=18)
    ax.yaxis.set_minor_locator(MultipleLocator(1))


def plot_aims(ax, recp_latt, dir_aims, remove_highest_bands: int, ref: str):
    # QP band
    band_files_aims = sorted(dir_aims.glob("GW_band10*.out"))
    bs_aims_band, kpts_aims_band = read_band_output(*band_files_aims, unit="eV")
    bs_aims_band += get_chemical_potential(dir_aims / "aims.out")
    kp = KPathLinearizer(kpts_aims_band, recp_latt)

    # k-grid QP
    bs_aims_grid, kpts_aims_grid = StdOut(dir_aims / "aims.out").get_QP_bandstructure()

    # Set reference
    ref_aims = 0
    if ref == "vbm":
        ref_aims = bs_aims_grid.vbm
    elif ref.startswith("vbm_"):
        # use VBM at first (usually ) point as VBM reference
        ref_aims = bs_aims_grid.vbm_sp_kp[0, int(ref.split("_")[1])]
    elif ref == "cbm":
        ref_aims = bs_aims_grid.cbm

    scatter_aims = [[], []]
    mapping = kp.locate(kpts_aims_grid)
    for ikgrid, ikbands in enumerate(mapping):
        if ikbands is None:
            continue
        for ikband in ikbands:
            for ib in range(bs_aims_grid.nbands - remove_highest_bands):
                scatter_aims[0].append(ikband)
                scatter_aims[1].append(bs_aims_grid.eigen[0, ikgrid, ib])
    scatter_aims = np.array(scatter_aims)

    # Plot
    for ib in range(bs_aims_band.nbands - remove_highest_bands):
        label = None
        if ib == 0:
            label = "FHI-aims"
        ax.plot(kp.x, bs_aims_band.eigen[0, :, ib] - ref_aims, label=label, color="k", ls="--")
    ax.scatter(scatter_aims[0], scatter_aims[1] - ref_aims,
               color="k", marker=".", s=MARKERSIZE)
    return kp


def plot_librpa(ax, recp_latt, dir_librpa, remove_highest_bands, ref, label: str,
                kind: str = "qp", stdout: str = "LibRPA.out",
                c=(0.8, 0, 0), draw_kgrids: bool = True, **kwargs):
    # QP band
    if kind == "qp":
        bs_librpa_band, kpts_librpa_band = read_band_output(dir_librpa / "GW_band_spin_1.dat", unit="eV")
    elif kind == "exx":
        bs_librpa_band, kpts_librpa_band = read_band_output(dir_librpa / "EXX_band_spin_1.dat", unit="eV")
    elif kind == "ks":
        bs_librpa_band, kpts_librpa_band = read_band_output(dir_librpa / "KS_band_spin_1.dat", unit="eV")
    kp = KPathLinearizer(kpts_librpa_band, recp_latt)
    # k-grid QP
    bs_librpa_grid, kpts_librpa_grid = read_quasi_particle_energies_stdout(dir_librpa / stdout, kind=kind)

    # Set reference
    ref_librpa = 0
    if ref == "vbm":
        ref_librpa = bs_librpa_grid.vbm
    elif ref.startswith("vbm_"):
        # use VBM at first (usually ) point as VBM reference
        ref_librpa = bs_librpa_grid.vbm_sp_kp[0, int(ref.split("_")[1])]
    elif ref == "cbm":
        ref_librpa = bs_librpa_grid.cbm

    scatter_librpa = [[], []]
    mapping = kp.locate(kpts_librpa_grid)
    for ikgrid, ikbands in enumerate(mapping):
        if ikbands is None:
            continue
        for ikband in ikbands:
            for ib in range(bs_librpa_grid.nbands - remove_highest_bands):
                scatter_librpa[0].append(ikband)
                scatter_librpa[1].append(bs_librpa_grid.eigen[0, ikgrid, ib])
    scatter_librpa = np.array(scatter_librpa)

    # Plot
    for ib in range(bs_librpa_band.nbands - remove_highest_bands):
        label_ = None
        if ib == 0:
            label_ = label
        ax.plot(kp.x, bs_librpa_band.eigen[0, :, ib] - ref_librpa, label=label_, color=c, **kwargs)
    if draw_kgrids:
        ax.scatter(scatter_librpa[0], scatter_librpa[1] - ref_librpa,
                   color=c, marker=".", s=MARKERSIZE)

    return kp


if __name__ == '__main__':
    # Create two subplots side by side
    fig, ax1 = plt.subplots(1, 1, figsize=(7, 6))

    # Si
    recp_latt = get_recp_latt_from_geometry(DATADIR / "geometry.in")
    dir_aims = DATADIR
    dir_librpa = DATADIR
    remove_highest_bands = 25
    emin = -10
    emax = 16
    control = read_control(dir_aims / "control.in")
    ksymbols = get_path_ksymbols(control.get_output("band"))
    ksymbols = [r"$\Gamma$" if x == "G" else x for x in ksymbols]
    # kp_aims = plot_aims(ax1, recp_latt, dir_aims, remove_highest_bands, "vbm")
    kp_librpa_ks = plot_librpa(ax1, recp_latt, dir_librpa, remove_highest_bands, "vbm", "PBE", "ks", c="k", ls="--", draw_kgrids=False)
    # kp_librpa_ex = plot_librpa(ax1, recp_latt, dir_librpa, remove_highest_bands, "vbm", r"EXX@PBE", "exx", c="b", ls=":", draw_kgrids=False)
    kp_librpa_gw = plot_librpa(ax1, recp_latt, dir_librpa, remove_highest_bands, "vbm", r"$G^0W^0$@PBE", "qp", draw_kgrids=False)
    set_ax(ax1, kp_librpa_gw, ksymbols, emin, emax)

    ax1.legend()

    # Adjust layout
    fn = "band.svg"
    fig.savefig(fn,
                dpi=300,
                bbox_inches='tight',
                pad_inches=0.1)
    plt.show()
